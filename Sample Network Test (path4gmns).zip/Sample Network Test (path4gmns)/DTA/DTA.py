import path4gmns as pg

network = pg.read_network()
print('\nstart zone synthesis')
# by default, grid_dimension is 8, total_demand is 10,000,
# time_budget is 120 min, mode is 'a'
pg.network_to_zones(network)
pg.output_zones(network)
pg.output_synthesized_demand(network)

print('complete zone and demand synthesis.\n')

# UE + DTA
column_gen_num = 10
column_update_num = 10
pg.perform_column_generation(column_gen_num, column_update_num, network)
pg.perform_simple_simulation(network)
print('complete dynamic simulation.\n')

print('writing agent trajectories')
pg.output_agent_trajectory(network)