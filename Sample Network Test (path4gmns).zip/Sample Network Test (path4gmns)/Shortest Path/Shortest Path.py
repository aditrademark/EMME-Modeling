import path4gmns as pg

network = pg.read_network()

# node path from node 205 to node 266, auto mode
print('\nshortest path (node id) from node 205 to node 266, '
      +network.find_shortest_path(205, 266, mode='a'))
print('\nshortest path (link id) from node 205 to node 266, '
      +network.find_shortest_path(205, 266, mode='a', seq_type='link'))
# link path from node 205 to node 266, walk mode
print('\nshortest path (node id) from node 205 to node 266, '
      +network.find_shortest_path(205, 266, mode='w'))
print('\nshortest path (link id) from node 205 to node 266, '
      +network.find_shortest_path(205, 266, mode='w' ,seq_type='link'))