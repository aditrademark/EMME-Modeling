import path4gmns as pg

network = pg.read_network()


print('\nstart zone synthesis')
# by default, grid_dimension is 8, total_demand is 10,000,
# time_budget is 120 min, mode is 'a'
pg.network_to_zones(network)
pg.output_zones(network)
pg.output_synthesized_demand(network)

print('complete zone and demand synthesis.\n')


pg.read_zones(network)
pg.load_demand(network)

column_gen_num = 20
column_update_num = 10

# path-based UE only
pg.perform_column_generation(column_gen_num, column_update_num, network)

# if you do not want to include geometry info in the output file,
# use pg.output_columns(network, False)
pg.output_columns(network)
pg.output_link_performance(network)