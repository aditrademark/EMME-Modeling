import path4gmns as pg

network = pg.read_network()

print('\nstart accessibility evaluation\n')
# no need to load demand file for accessibility evaluation
pg.evaluate_accessibility(network)

print('complete accessibility evaluation.\n')

print('\nstart equity evaluation\n')
# multimodal equity evaluation under default time budget (60 min)
pg.evaluate_equity(network)
# equity evaluation for a target mode with time budget as 30 min
# pg.evaluate_equity(network, single_mode=True, mode='a', time_budget=30)

print('complete equity evaluation.\n')